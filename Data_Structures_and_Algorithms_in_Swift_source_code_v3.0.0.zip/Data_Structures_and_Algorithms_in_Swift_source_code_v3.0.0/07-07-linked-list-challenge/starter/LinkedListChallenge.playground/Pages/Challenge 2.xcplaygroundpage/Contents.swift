// Copyright (c) 2019 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 [Previous Challenge](@previous)
 ## Challenge 2: Find the middle node

 Create a function that finds the middle node of a linked list.
 */
func getMiddle<T>(_ list: LinkedList<T>) -> Node<T>? {
  nil // placeholder 
}

//: [Next Challenge](@next)
