// Copyright (c) 2019 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
//: [Previous Challenge](@previous)
/*:
 ## 2. Merge Sort or Quicksort
 
 Explain when and why you would use merge sort over quicksort.
 */

/*
Your answer here.
 */

//: [Next Challenge](@next)
