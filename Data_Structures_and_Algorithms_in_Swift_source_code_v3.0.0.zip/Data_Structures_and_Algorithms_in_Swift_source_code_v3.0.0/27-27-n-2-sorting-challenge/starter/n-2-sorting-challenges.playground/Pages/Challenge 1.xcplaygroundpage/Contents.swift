// Copyright (c) 2019 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
//: # n² Sorting Challenges
//: ## Challenge 1: Group elements
//: Given a collection of Equatable elements, bring all instances of a given
//: value in the array to the right side of the array.

// Your code here

var array = [3, 4, 134, 3, 5, 6, 3, 5, 6, 1, 0]

//array.rightAlign(value: 3)
print(array)

//: [Next Challenge](@next)
