import Cocoa

class  LinkedListReferenceType  {
    var  value:  String
    var  next:  LinkedListReferenceType?
    init(value:  String)  {
        self.value  =  value
    }
}

