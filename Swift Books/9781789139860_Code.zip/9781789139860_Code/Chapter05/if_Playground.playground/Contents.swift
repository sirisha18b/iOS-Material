import Cocoa

let teamOneScore = 7
let teamTwoScore = 6
if teamOneScore>teamTwoScore {
    print("Team One Won")
} else if teamTwoScore>teamOneScore {
    print("Team Two Won")
} else {
    print("We have a tie")
}


