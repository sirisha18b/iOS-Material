import Cocoa

let number = 4

if number % 2 == 0 {
    print("Even")
} else {
    print("Odd")
}

if number.isMultiple(of: 2) {
    print("Even")
} else {
    print("Odd")
}


