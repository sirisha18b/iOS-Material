import Cocoa

var team = ("Boston", "Red Sox", 97, 65, 59.9)
//var (city, name, wins, loses, percent) = team

var city = team.0
var name = team.1
var wins = team.2
var loses = team.3
var percent = team.4

