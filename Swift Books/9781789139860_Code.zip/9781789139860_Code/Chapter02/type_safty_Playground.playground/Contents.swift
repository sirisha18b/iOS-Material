import Cocoa

var integerVar = 10
integerVar = "My String"

