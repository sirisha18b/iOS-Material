import Cocoa

/**
var a: Int = 3
var b: Double = 0.14
var c = a + b
*/


var a: Int = 3
var b: Double = 0.14
var c = Double(a) + b
