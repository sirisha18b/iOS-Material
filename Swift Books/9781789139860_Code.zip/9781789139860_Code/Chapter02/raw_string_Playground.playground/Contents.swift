import Cocoa

let str = "The main character said \"hello\""

let str1 = #"The main character said "hello""#

let ans = 42
var str2 = #"The answer is \#(ans)"#
