import Cocoa

var str = "Hello, playground"
var image = NSImage(named: "swift.png")

