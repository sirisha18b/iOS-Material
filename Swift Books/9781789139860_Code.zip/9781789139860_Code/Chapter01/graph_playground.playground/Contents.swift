import Cocoa
/**
 
 */
var j = 1
for i in 1...5 {
    j += i
}
