import Cocoa

var myString1: String?
myString1 = "test"
if myString1 != nil {
    var test = myString1!
}


