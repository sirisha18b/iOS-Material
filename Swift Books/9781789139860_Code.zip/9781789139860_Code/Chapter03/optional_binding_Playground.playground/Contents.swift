import Cocoa

var myString3: String?
myString3 = "Space, the final frontier"
if let tempVar = myString3 {
    print(tempVar)
} else {
    print("No value")
}

