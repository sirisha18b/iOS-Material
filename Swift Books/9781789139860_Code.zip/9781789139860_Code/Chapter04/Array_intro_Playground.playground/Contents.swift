import Cocoa

let arrayOne = [1,2,3,4,5,6]

var arrayTwo = [4,5,6]

var arrayThree = [Int]()

var arrayFour: [Int] = []

var multiArrayOne = [[1,2],[3,4],[5,6]]
var multiArrayTwo = [[Int]]()

print(arrayOne[0])    //Displays '1'
print(arrayOne[3])    //Displays '4'

let multiArray = [[1,2],[3,4],[5,6]]
let arr = multiArray[0] //arr contains the array [1,2]
let value = multiArray[0][1] //value contains 2



